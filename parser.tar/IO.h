#ifndef IO_H
#define IO_H

void prototype();

#endif